=== Elementor Addon - Cincopa video and media plugin ===
Contributors: cincopa
Tags: cincopa, video, media, elementor, addon, gallery, playlist
Requires at least: 5.0
Tested up to: 7.0
Stable tag: 1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Post video players, slideshow albums, photo galleries and music / podcast playlist.

== Description ==

This is an Elementor Addon for Cincopa, enabling users to easily insert video players, slideshow albums, photo galleries, and music/podcast playlists directly into Elementor pages.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/elementor-addon` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the Cincopa widget within the Elementor builder.

== Frequently Asked Questions ==

= Does this require the main Cincopa plugin? =

Yes, this addon integrates with the main "Cincopa video and media plug-in" for WordPress.

== Changelog ==

= 1.1 =
* First stable release.
