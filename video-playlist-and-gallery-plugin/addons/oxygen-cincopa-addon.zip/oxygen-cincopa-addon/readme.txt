=== Oxygen Addon - Cincopa video and media plugin ===
Contributors: cincopa
Tags: video, gallery, oxygen, media, playlist
Requires at least: 4.6
Tested up to: 7.0
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Post video players, slideshow albums, photo galleries and music / podcast playlist.

== Description ==

Oxygen Addon for Cincopa video and media plugin. Effortlessly add and configure Cincopa video players, slideshow albums, photo galleries, and music/podcast playlists directly inside the Oxygen builder interface.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/oxygen-cincopa-addon` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.

== Changelog ==

= 1.0 =
* Initial release.
